-- Generado por Ricing HGUI. NO EDITAR A MANO.
-- Añadir `require("config.ui-bindings")` en hyprland.lua tras los binds habituales.

